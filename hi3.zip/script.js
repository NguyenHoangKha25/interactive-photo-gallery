function highlight(event) {
  event.currentTarget.style.border = "3px solid blue";
  console.log("Hovered or Focused on:", event.currentTarget);
}

function unhighlight(event) {
  event.currentTarget.style.border = "2px solid #ccc";
  console.log("Mouse left or Blurred on:", event.currentTarget);
}

window.onload = function () {
  const figures = document.querySelectorAll("figure");
  for (let i = 0; i < figures.length; i++) {
    figures[i].addEventListener("mouseover", highlight);
    figures[i].addEventListener("mouseleave", unhighlight);
    figures[i].addEventListener("focus", highlight);
    figures[i].addEventListener("blur", unhighlight);
    figures[i].setAttribute("tabindex", "0");
  }
  console.log("Page loaded and event listeners attached");
};
